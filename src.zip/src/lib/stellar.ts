import * as StellarSdk from "@stellar/stellar-sdk";

const CONTRACT_ID = "CC3LVU2R3IFXK2EGFUNHJAGCJM5DE6DJZRXMGZMWBTRV2GVLNEK3ML3R";
const NETWORK_PASSPHRASE = StellarSdk.Networks.TESTNET;
const HORIZON_URL = "https://horizon-testnet.stellar.org";

const server = new StellarSdk.Horizon.Server(HORIZON_URL);

export interface TokenData {
  name: string;
  symbol: string;
  creator: string;
  totalSupply: string;
  timestamp: string;
}

export interface CreateTokenResult {
  txHash: string;
  tokenId: string;
}

export const createToken = async (
  name: string,
  symbol: string,
  supply: string,
  walletAddress: string
): Promise<CreateTokenResult> => {
  try {
    // Load the account
    const account = await server.loadAccount(walletAddress);

    // Build the contract invocation
    const contract = new StellarSdk.Contract(CONTRACT_ID);
    
    // Convert parameters to ScVal
    const nameScVal = StellarSdk.nativeToScVal(name, { type: "string" });
    const symbolScVal = StellarSdk.nativeToScVal(symbol, { type: "string" });
    const supplyScVal = StellarSdk.nativeToScVal(BigInt(supply), { type: "u128" });

    // Build the transaction
    const transaction = new StellarSdk.TransactionBuilder(account, {
      fee: StellarSdk.BASE_FEE,
      networkPassphrase: NETWORK_PASSPHRASE,
    })
      .addOperation(
        contract.call("create_token", nameScVal, symbolScVal, supplyScVal)
      )
      .setTimeout(30)
      .build();

    // Sign with Freighter using window.freighter
    const signedResult = await (window as any).freighter.signTransaction(
      transaction.toXDR(),
      {
        networkPassphrase: NETWORK_PASSPHRASE,
      }
    );

    // Extract the signed XDR
    const signedXDR = typeof signedResult === 'string' ? signedResult : signedResult.signedTxXdr;

    // Submit the transaction
    const transactionToSubmit = StellarSdk.TransactionBuilder.fromXDR(
      signedXDR,
      NETWORK_PASSPHRASE
    );

    const response = await server.submitTransaction(transactionToSubmit as any);

    // Generate a mock token ID (in real implementation, this would come from contract)
    const tokenId = `TOKEN_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    return {
      txHash: response.hash,
      tokenId,
    };
  } catch (error: any) {
    console.error("Create token error:", error);
    throw new Error(error.message || "Failed to create token");
  }
};

export const getTokenInfo = async (tokenId: string): Promise<TokenData | null> => {
  try {
    // In a real implementation, this would query the contract
    // For now, returning mock data for demonstration
    
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000));

    // Mock data - in production, this would come from the contract
    if (tokenId.startsWith("TOKEN_")) {
      return {
        name: "Demo Token",
        symbol: "DEMO",
        creator: "GABC123456789EXAMPLE123456789EXAMPLE123456789EXAMPLE12",
        totalSupply: "1000000",
        timestamp: new Date().toISOString(),
      };
    }

    return null;
  } catch (error) {
    console.error("Get token info error:", error);
    return null;
  }
};

export const getTotalTokens = async (): Promise<number> => {
  try {
    // In a real implementation, this would query the contract
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 500));

    // Mock data - in production, this would come from the contract
    return Math.floor(Math.random() * 100) + 50;
  } catch (error) {
    console.error("Get total tokens error:", error);
    return 0;
  }
};
