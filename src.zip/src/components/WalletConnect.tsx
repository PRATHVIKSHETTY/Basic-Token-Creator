import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Wallet } from "lucide-react";

interface WalletConnectProps {
  onConnect: (address: string) => void;
  connectedAddress: string | null;
}

export const WalletConnect = ({ onConnect, connectedAddress }: WalletConnectProps) => {
  const [isChecking, setIsChecking] = useState(false);

  const handleConnect = async () => {
    setIsChecking(true);
    try {
      // Check if Freighter is installed
      if (!(window as any).freighter) {
        window.open("https://freighter.app/", "_blank");
        return;
      }

      // Request access
      const publicKey = await (window as any).freighter.getPublicKey();
      if (publicKey) {
        onConnect(publicKey);
      }
    } catch (error) {
      console.error("Failed to connect wallet:", error);
    } finally {
      setIsChecking(false);
    }
  };

  const truncateAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  return (
    <Card className="p-6 bg-gradient-card border-border/50 shadow-card">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-primary/10 border border-primary/20">
            <Wallet className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">Freighter Wallet</h3>
            <p className="text-sm text-muted-foreground">
              {connectedAddress ? truncateAddress(connectedAddress) : "Not connected"}
            </p>
          </div>
        </div>
        {!connectedAddress && (
          <Button
            onClick={handleConnect}
            disabled={isChecking}
            className="bg-gradient-primary hover:opacity-90 transition-opacity shadow-glow"
          >
            {isChecking ? "Checking..." : "Connect Wallet"}
          </Button>
        )}
        {connectedAddress && (
          <div className="px-4 py-2 rounded-lg bg-primary/10 border border-primary/20 text-primary text-sm font-medium">
            Connected
          </div>
        )}
      </div>
    </Card>
  );
};
